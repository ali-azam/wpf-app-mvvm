﻿using System;
using CustomerModel;
using FactoryCustomer;

namespace CustomerViewModel
{
    public class CustViewModel
    {
        private CustomerBase cust = null;

        public CustViewModel()
        {
            cust = Factory.Create("Customer");
        }

        public string txtCustomerName
        {
            get { return cust.CustomerName; }
            set { cust.CustomerName = value; }
        }
        public string txtPhoneNumber
        {
            get { return cust.Phonenumber; }
            set { cust.Phonenumber = value; }
        }
        public string txtBillAmount
        {
            get { return cust.BillAmount.ToString(); }
            set { cust.BillAmount = Convert.ToDecimal(value); }
        }
        public string txtBillDate
        {
            get { return cust.BillDate.ToString(); }
            set { cust.BillDate = Convert.ToDateTime(value); }
        }
        public string txtAddress
        {
            get { return cust.CustomerAddress; }
            set { cust.CustomerAddress = value; }
        }
    }
}
