﻿using System;

namespace CustomerModel     //MiddleLayer --> which contains the business logic [also known as Business Layer (BL)]
{
    public class CustomerBase
    {
        public string CustomerName { get; set; }
        public string Phonenumber { get; set; }
        public decimal BillAmount { get; set; }
        public DateTime BillDate { get; set; }
        public string CustomerAddress { get; set; }

        public CustomerBase()
        {
            CustomerName = "";
            Phonenumber = "";
            BillAmount = 0;
            BillDate = DateTime.Now;
            CustomerAddress = "";
        }

        public virtual void Validate()
        {
            throw new Exception("Not implemented");
        }
    }

    public class Customer : CustomerBase
    {
        public override void Validate()
        {
            if (CustomerName.Length == 0)
            {
                throw new Exception("Customer Name is required");
            }
            if (Phonenumber.Length == 0)
            {
                throw new Exception("Phone Number is required");
            }
            if (BillAmount == 0)
            {
                throw new Exception("Bill Amount is required");
            }
            if (BillDate >= DateTime.Now)
            {
                throw new Exception("Bill date can not exceed todays date");
            }
            if (CustomerAddress.Length == 0)
            {
                throw new Exception("Address is required");
            }
        }
    }

    public class Lead : CustomerBase
    {
        public override void Validate()
        {
            if (CustomerName.Length == 0)
            {
                throw new Exception("Customer Name is required");
            }
            if (Phonenumber.Length == 0)
            {
                throw new Exception("Phone Number is required");
            }

        }
    }
}
