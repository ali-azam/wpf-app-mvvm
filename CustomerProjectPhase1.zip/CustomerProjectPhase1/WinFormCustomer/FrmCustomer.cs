﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CustomerModel;
using FactoryCustomer;

namespace WinFormCustomer
{
    public partial class FrmCustomer : Form
    {
        private CustomerBase cust = null;
        
        public FrmCustomer()
        {
            InitializeComponent();
        }

        private void FrmCustomer_Load(object sender, EventArgs e)
        {
            txtBillAmount.Text = "0";
            txtBillDate.Text = "1/1/2010";
        }

        private void cmbCustomerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Polimorphism -> Objects' behaviour is changed in different conditions
            /*if (cmbCustomerType.Text == "Customer")
            {
                cust = new Customer();
            }
            else
            {
                cust = new Lead();
            }*/

            cust = Factory.Create(cmbCustomerType.Text);
        }

        private void SetCustomer()
        {
            cust.CustomerName = txtCustomerName.Text;
            cust.Phonenumber = txtPhoneNumber.Text;
            cust.BillAmount = Convert.ToDecimal(txtBillAmount.Text);
            cust.BillDate = Convert.ToDateTime(txtBillDate.Text);
            cust.CustomerAddress = txtAddress.Text;
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                SetCustomer();
                cust.Validate();

                MessageBox.Show(cmbCustomerType.Text + " validation success");
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
