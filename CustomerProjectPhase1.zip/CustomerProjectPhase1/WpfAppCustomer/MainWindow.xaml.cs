﻿using System;
using System.Windows;
using System.Windows.Controls;
using CustomerModel;
using FactoryCustomer;

namespace WpfAppCodeBehind
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private CustomerBase cust = null;

        public MainWindow()
        {
            InitializeComponent();
            txtBillAmount.Text = "0";
            txtBillDate.Text = "1/1/2010";
        }
        
        private void CmbCustomerType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Polimorphism -> Objects' behaviour is changed in different conditions
            /*if (cmbCustomerType.Text == "Customer")
            {
                cust = new Customer();
            }
            else
            {
                cust = new Lead();
            }*/
            
            ComboBoxItem ComboItem = (ComboBoxItem)cmbCustomerType.SelectedItem;
            string name = ComboItem.Content.ToString();

            cust = Factory.Create(name);
        }

        private void SetCustomer()
        {
            cust.CustomerName = txtCustomerName.Text;                   //binding code
            cust.Phonenumber = txtPhoneNumber.Text;                     //binding code
            cust.BillAmount = Convert.ToDecimal(txtBillAmount.Text);    //Transformation (conversion) code + binding code
            cust.BillDate = Convert.ToDateTime(txtBillDate.Text);       //Transformation (conversion) code + binding code
            cust.CustomerAddress = txtAddress.Text;                     //binding code
        }

        private void BtnValidate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SetCustomer();
                cust.Validate();

                MessageBox.Show(cmbCustomerType.Text + " validation successful");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
